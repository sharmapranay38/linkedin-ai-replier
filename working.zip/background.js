// Background script to handle storage access and extension icon clicks
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getApiKey") {
    chrome.storage.sync.get("geminiKey", (result) => {
      sendResponse({ apiKey: result.geminiKey });
    });
    return true; // Keep the message channel open for async response
  }
  
  if (request.action === "getSettings") {
    chrome.storage.sync.get(['geminiKey', 'darkMode', 'replyHistory', 'savedTemplates'], (result) => {
      sendResponse(result);
    });
    return true; // Keep the message channel open for async response
  }
  
  if (request.action === "saveApiKey") {
    chrome.storage.sync.set({ geminiKey: request.apiKey }, () => {
      sendResponse({ success: true });
    });
    return true; // Keep the message channel open for async response
  }
  
  if (request.action === "saveHistory") {
    chrome.storage.sync.set({ replyHistory: request.history }, () => {
      sendResponse({ success: true });
    });
    return true; // Keep the message channel open for async response
  }
});

// Handle extension icon click
chrome.action.onClicked.addListener(async (tab) => {
  // Only work on LinkedIn pages
  if (tab.url && tab.url.includes('linkedin.com')) {
    try {
      // Inject the content script if not already injected
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });
      
      // Send message to toggle the panel
      await chrome.tabs.sendMessage(tab.id, { action: 'togglePanel' });
    } catch (error) {
      console.log('Content script already injected or error:', error);
      // Try to send the toggle message anyway
      try {
        await chrome.tabs.sendMessage(tab.id, { action: 'togglePanel' });
      } catch (e) {
        console.log('Could not send toggle message:', e);
      }
    }
  } else {
    // Show a notification for non-LinkedIn pages
    chrome.action.setBadgeText({ text: '!' });
    chrome.action.setBadgeBackgroundColor({ color: '#ff0000' });
    setTimeout(() => {
      chrome.action.setBadgeText({ text: '' });
    }, 2000);
  }
}); 