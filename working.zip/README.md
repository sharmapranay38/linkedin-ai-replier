# LinkedIn AI Replier Chrome Extension

A powerful Chrome extension that uses Google's Gemini AI to generate intelligent, contextual replies for LinkedIn comments.

## 🚀 Features

### Core AI Features
- **Gemini AI Integration** - Powered by Google's latest AI model
- **7 Tone Options** - Formal, Friendly, Insightful, Funny, Thanks, Plug Product, Custom
- **Smart Context Understanding** - Analyzes the original comment for better replies
- **Custom Instructions** - Add your own specific guidelines for AI responses

### Response Customization
- **Length Control** - Short, Medium, or Long replies
- **End with Question** - Automatically add engaging questions
- **Hashtag Integration** - Include relevant hashtags
- **Emoji Support** - Add appropriate emojis
- **Business Focus** - Keep responses professional
- **Bullet Format** - Use bullet points for better readability

### Productivity Features
- **Reply History** - Save and reuse your best replies
- **Template System** - Create and save reply templates
- **Quick Actions** - One-click common responses
- **Auto-Save High Engagement** - Automatically save successful replies as templates
- **Engagement Tracking** - Visual indicators for reply performance

### User Experience
- **Dark Mode** - Toggle between light and dark themes
- **Keyboard Shortcuts** - Power user shortcuts for faster workflow
- **Copy to Clipboard** - One-click copying of generated replies
- **Edit Replies** - Modify AI-generated content before using
- **Regenerate** - Get alternative reply suggestions

## ⌨️ Keyboard Shortcuts

- **Ctrl/Cmd + Enter** - Generate reply
- **Ctrl/Cmd + C** - Copy reply to clipboard
- **Ctrl/Cmd + H** - Open reply history
- **Ctrl/Cmd + T** - Open saved templates
- **Ctrl/Cmd + Q** - Open quick actions
- **Escape** - Close popup
- **1-7** - Quick tone selection (1=Formal, 2=Friendly, etc.)

## 🎨 Quick Actions

- **Thank You** - Express gratitude
- **Agree** - Show agreement with the comment
- **Ask Question** - Engage with a relevant question
- **Add Insight** - Share your perspective
- **Connect** - Express interest in connecting
- **Share Experience** - Relate personal experience

## 📊 Engagement Tracking

The extension automatically tracks engagement scores for your replies:
- **High Engagement (8-10)** - Green border, auto-saved as template
- **Medium Engagement (5-7)** - Yellow border
- **Low Engagement (1-4)** - Red border

## 🛠️ Installation

1. Download or clone this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the extension folder
5. Get your Gemini API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
6. Click the extension icon and go to Settings to add your API key

## 🔧 Setup

1. **API Key Configuration**
   - Click the extension icon
   - Click "Settings" in the footer
   - Enter your Gemini API key
   - Click "Save API Key"

2. **Using the Extension**
   - Select text from a LinkedIn comment
   - Click the extension icon
   - Choose your preferred tone and options
   - Click "Generate Reply"
   - Copy and paste the reply

## 🎯 Best Practices

- **Select Relevant Text** - Highlight the specific comment you want to reply to
- **Use Appropriate Tones** - Match the tone to the context and your relationship
- **Customize Instructions** - Use custom tone for specific scenarios
- **Save Successful Replies** - Build a library of effective templates
- **Monitor Engagement** - Learn which reply styles work best

## 🔒 Privacy & Security

- All data is stored locally in your browser
- API keys are encrypted in Chrome's secure storage
- No data is sent to external servers except for AI generation
- You can clear all data by removing the extension

## 🚀 Future Features

- Multiple AI model support
- Advanced analytics dashboard
- Team collaboration features
- Industry-specific templates
- Multi-language support
- Voice input support

## 📝 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📞 Support

If you encounter any issues or have feature requests, please open an issue on GitHub.

---

**Note**: This extension requires a valid Gemini API key to function. The API key is used only for generating replies and is not stored or transmitted anywhere else. 